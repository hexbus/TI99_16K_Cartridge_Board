This 16K .pcb file was made with ExpressPCB (www.expresspcb.com).

You can use and make changes to this file as long as the copyright notices
remain intact on the board and this file is distributed with it.  

This file is (c) 2009 www.hexbus.com, (c) 2007 www.ti-994a.com. Thanks to 
www.mainbyte.com for the idea to make this.

If you make any changes and would like to share them with me, I would love to
see this board continue to improve and become something more....

Jon Guidry
www.hexbus.com
acadiel%guidry.org (replace % with @)
